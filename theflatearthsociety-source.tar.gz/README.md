Development moved to https://gitlab.com/blacknet-ninja

https://theflatearthsociety.org/ aims to continue on TheFlatEarthSociety chain.
